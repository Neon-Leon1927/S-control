import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'S-control',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePageWidget(), // ← Вот это ключевое изменение
    );
  }
}
// Модель для хранения данных о записи сахара и углеводов
class SugarRecord {
  final DateTime date;
  final double sugarLevel;
  final double carbs;
  final double? insulin;

  SugarRecord({
    required this.date,
    required this.sugarLevel,
    required this.carbs,
    this.insulin,
  });
}

// Модель для продукта
class Product {
  final String name;
  final double carbsPer100g;
  final double breadUnits; // ХЕ (хлебные единицы)

  Product({
    required this.name,
    required this.carbsPer100g,
  }) : breadUnits = carbsPer100g / 10; // 1 ХЕ = 10г углеводов
}

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  // Контроллеры для текстовых полей
  final TextEditingController _sugarController = TextEditingController();
  final TextEditingController _carbsController = TextEditingController();
  final TextEditingController _insulinController = TextEditingController();
  final TextEditingController _carbsPer100Controller = TextEditingController();
  final TextEditingController _productWeightController = TextEditingController();

  // Список записей
  final List<SugarRecord> _records = [];
  
  // Список продуктов
  final List<Product> _products = [
    Product(name: "Яблоко", carbsPer100g: 11.4),
    Product(name: "Банан", carbsPer100g: 22.6),
    Product(name: "Хлеб белый", carbsPer100g: 49.2),
    Product(name: "Гречка", carbsPer100g: 72.0),
    Product(name: "Молоко", carbsPer100g: 4.7),
    Product(name: "Картофель вареный", carbsPer100g: 16.7),
    Product(name: "Макароны", carbsPer100g: 71.5),
    Product(name: "Шоколад молочный", carbsPer100g: 54.4),
  ];

  // Результат расчета ХЕ
  double _xeResult = 0.0;

  @override
  void dispose() {
    _sugarController.dispose();
    _carbsController.dispose();
    _insulinController.dispose();
    _carbsPer100Controller.dispose();
    _productWeightController.dispose();
    super.dispose();
  }

  // Функция для записи данных о сахаре и углеводах
  void _addRecord() {
    final sugar = double.tryParse(_sugarController.text) ?? 0.0;
    final carbs = double.tryParse(_carbsController.text) ?? 0.0;
    final insulin = double.tryParse(_insulinController.text);

    if (sugar > 0 || carbs > 0) {
      setState(() {
        _records.insert(0, SugarRecord(
          date: DateTime.now(),
          sugarLevel: sugar,
          carbs: carbs,
          insulin: insulin,
        ));
        
        // Очищаем поля после записи
        _sugarController.clear();
        _carbsController.clear();
        _insulinController.clear();
      });
    }
  }

  // Функция для расчета хлебных единиц
  void _calculateXE() {
    final carbsPer100 = double.tryParse(_carbsPer100Controller.text) ?? 0.0;
    final weight = double.tryParse(_productWeightController.text) ?? 0.0;

    if (carbsPer100 > 0 && weight > 0) {
      setState(() {
        _xeResult = (carbsPer100 * weight / 100) / 10; // Расчет ХЕ
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('S-control'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Дневник'),
              Tab(text: 'ХЕ'),
              Tab(text: 'Продукты'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Первый экран - Дневник
            _buildDiaryTab(),
            // Второй экран - Расчет ХЕ
            _buildXETab(),
            // Третий экран - Список продуктов
            _buildProductsTab(),
          ],
        ),
      ),
    );
  }

  Widget _buildDiaryTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Поле для ввода уровня сахара
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _sugarController,
              decoration: const InputDecoration(
                labelText: 'Уровень сахара в крови',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          
          // Поле для ввода углеводов
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _carbsController,
              decoration: const InputDecoration(
                labelText: 'Количество углеводов (г)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          
          // Поле для ввода инсулина
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _insulinController,
              decoration: const InputDecoration(
                labelText: 'Введённый инсулин (ед)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          
          // Кнопка записи
          ElevatedButton(
            onPressed: _addRecord,
            child: const Text('Записать'),
          ),
          
          // Список записей
          if (_records.isNotEmpty)
            DataTable(
              columns: const [
                DataColumn(label: Text('Дата')),
                DataColumn(label: Text('Сахар')),
                DataColumn(label: Text('Углеводы')),
                DataColumn(label: Text('Инсулин')),
              ],
              rows: _records.map((record) {
                return DataRow(cells: [
                  DataCell(Text('${record.date.hour}:${record.date.minute}')),
                  DataCell(Text(record.sugarLevel.toStringAsFixed(1))),
                  DataCell(Text(record.carbs.toStringAsFixed(1))),
                  DataCell(Text(record.insulin?.toStringAsFixed(1) ?? '-')),
                ]);
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildXETab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text('Хлебная единица (ХЕ) = 10 грамм углеводов'),
          ),
          
          // Поле для ввода углеводов на 100г
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _carbsPer100Controller,
              decoration: const InputDecoration(
                labelText: 'Углеводы на 100г продукта',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          
          // Поле для ввода веса продукта
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _productWeightController,
              decoration: const InputDecoration(
                labelText: 'Вес продукта (г)',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
          ),
          
          // Кнопка расчета
          ElevatedButton(
            onPressed: _calculateXE,
            child: const Text('Рассчитать'),
          ),
          
          // Результат расчета
          if (_xeResult > 0)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Хлебных единиц: ${_xeResult.toStringAsFixed(1)} ХЕ',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildProductsTab() {
    return ListView.builder(
      itemCount: _products.length,
      itemBuilder: (context, index) {
        final product = _products[index];
        return Card(
          child: ListTile(
            title: Text(product.name),
            subtitle: Text('${product.carbsPer100g}г углеводов на 100г'),
            trailing: Text('${product.breadUnits?.toStringAsFixed(1)} ХЕ'),
          ),
        );
      },
    );
  }
}


