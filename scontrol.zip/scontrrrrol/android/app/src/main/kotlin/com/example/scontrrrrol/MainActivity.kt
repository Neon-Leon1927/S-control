package com.example.scontrrrrol

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
